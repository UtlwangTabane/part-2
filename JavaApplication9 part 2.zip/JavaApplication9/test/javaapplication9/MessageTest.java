/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
package javaapplication9;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    @Test
    public void testMessageLength_Success() {
        Message msg = new Message("+27831234567", "Hi Tonight", 0);
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testMessageLength_Failure() {
        String longMessage = "a".repeat(260);
        Message msg = new Message("+27831234567", longMessage, 0);
        String result = msg.checkMessageLength();
        assertTrue(result.contains("Message exceeds 250 characters by 10"));
    }

    @Test
    public void testRecipient_Success() {
        Message msg = new Message("+27831234567", "test", 0);
        assertTrue(msg.isValidRecipient());
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    @Test
    public void testRecipient_Failure() {
        Message msg = new Message("0831234567", "test", 0);
        assertFalse(msg.isValidRecipient());
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", msg.checkRecipientCell());
    }

    @Test
    public void testMessageHash() {
        Message msg = new Message("+27831234567", "Hi Tonight", 0);
        String hash = msg.createHash();
        assertTrue(hash.contains("HI"));
        assertTrue(hash.contains("TONIGHT"));
        assertTrue(hash.contains(":0:"));
        assertTrue(hash.contains(":"));
    }

    @Test
    public void testMessageID() {
        Message msg = new Message("+27831234567", "Test", 1);
        String id = msg.getMessageID();
        assertNotNull(id);
        assertEquals(10, id.length()); // Must be 10 digits
        assertTrue(msg.checkMessageID());
    }

    @Test
    public void testSentMessage() {
        Message msg = new Message("+27831234567", "Hello", 0);
        assertEquals("Message successfully sent.", msg.SentMessage(1));
        
        Message msg2 = new Message("+27831234567", "Hello", 1);
        assertEquals("Press 0 to delete message.", msg2.SentMessage(2));
        
        Message msg3 = new Message("+27831234567", "Hello", 2);
        assertEquals("Message successfully stored.", msg3.SentMessage(3));
    }

    @Test
    public void testTotalMessages() {
        // Check returnTotalMessages works
        Message msg = new Message("+27831234567", "Test", 0);
        int before = msg.returnTotalMessages();
        msg.SentMessage(1);
        int after = msg.returnTotalMessages();
        assertTrue(after >= before);
    }
}


