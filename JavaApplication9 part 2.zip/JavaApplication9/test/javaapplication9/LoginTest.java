/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package javaapplication9;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
    Login login;
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        login = new Login();
    }
    
    @After
    public void tearDown() {
    }

    // ===== USERNAME TESTS =====
    @Test
    public void testValidUsername() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testInvalidUsernameNoUnderscore() {
        assertFalse(login.checkUserName("kyle!!!!!!"));
    }

    @Test
    public void testInvalidUsernameTooLong() {
        assertFalse(login.checkUserName("kyle_123"));
    }

    // ===== PASSWORD TESTS =====
    @Test
    public void testValidPassword() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testInvalidPasswordNoSpecial() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    // ===== CELL NUMBER TESTS =====
    @Test
    public void testValidCellNumber() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testInvalidCellNumberNoPlus() {
        assertFalse(login.checkCellPhoneNumber("0838968976"));
    }

    // ===== LOGIN TESTS =====
    @Test
    public void testLoginSuccess() {
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!", "kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        assertFalse(login.loginUser("kyl_1", "wrong", "kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        String expected = "Welcome Kyle ,Smith it is great to see you.";
        assertEquals(expected, login.returnLoginStatus(true, "Kyle", "Smith"));
    }

    @Test
    public void testReturnLoginStatusFailed() {
        String expected = "Username or password incorrect, please try again.";
        assertEquals(expected, login.returnLoginStatus(false, "Kyle", "Smith"));
    }
}