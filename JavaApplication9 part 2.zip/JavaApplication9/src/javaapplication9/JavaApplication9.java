/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication9;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class JavaApplication9 {
   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        String firstName, lastName, username, password, cellNumber;

        System.out.println("REGISTRATION AND LOGIN SYSTEM");

        System.out.print("Enter your first name: ");
        firstName = input.nextLine();
        System.out.print("Enter your last name: ");
        lastName = input.nextLine();

        while (true) {
            System.out.print("Enter a username: ");
            username = input.nextLine();
            if (login.checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not successfully captured");
            }
        }

        while (true) {
            System.out.print("Enter password: ");
            password = input.nextLine();
            if (login.checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted");
            }
        }

        while (true) {
            System.out.print("Enter South African cell phone number (e.g. +27838968976): ");
            cellNumber = input.nextLine();
            if (login.checkCellPhoneNumber(cellNumber)) {
                System.out.println("Cell phone number successfully added.");
                break;
            } else {
                System.out.println("Cell phone number incorrectly formatted");
            }
        }

        System.out.println(login.registerUser(username, password, cellNumber));

        System.out.println("LOGIN");
        while (true) {
            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();
            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();

            boolean loggedIn = login.loginUser(loginUsername, loginPassword, username, password);
            System.out.println(login.returnLoginStatus(loggedIn, firstName, lastName));
            if (loggedIn) break;
        }
        
        System.out.println("Welcome to Quickchat.");
        
        int maxMessages = 0;
        while (true) {
            try {
                System.out.print("How many messages do you wish to enter? ");
                maxMessages = Integer.parseInt(input.nextLine());
                if (maxMessages > 0) break;
            } catch (Exception e) {
                System.out.println("Enter a valid number.");
            }
        }

        int messagesSentCounter = 0;
        // Run until user selects quit
        boolean running = true;
        while (running) {
            System.out.println("\n--- QuickChat Menu ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose: ");
            String choice = input.nextLine();

            switch (choice) {
                case "1":
                    //  Allow only set number
                    if (messagesSentCounter >= maxMessages) {
                        System.out.println("You have reached your message limit of " + maxMessages);
                        break;
                    }
                   
                    //  Each message contains info
                    String recipient;
                    while (true) {
                        System.out.print("Enter recipient (+27...): ");
                        recipient = input.nextLine();
                        Message temp = new Message(recipient, "test", messagesSentCounter);
                        System.out.println(temp.checkRecipientCell());
                        if (temp.isValidRecipient()) break;
                    }

                    String text;
                    while (true) {
                        System.out.print("Enter your message (max 250 chars): ");
                        text = input.nextLine();
                        Message temp = new Message(recipient, text, messagesSentCounter);
                        System.out.println(temp.checkMessageLength());
                        if (text.length() <= 250) break;
                    }

                    Message msg = new Message(recipient, text, messagesSentCounter);
                    System.out.println("MessageID: " + msg.getMessageID());
                    System.out.println("MessageHash: " + msg.createHash());

                    System.out.println("1) Send Message\n2) Disregard Message\n3) Store Message");
                    System.out.print("Choose what to do: ");
                    int sendChoice = Integer.parseInt(input.nextLine());
                    System.out.println(msg.SentMessage(sendChoice));

                    if (sendChoice == 1) {
                        messagesSentCounter++;
                        System.out.println("\n" + msg.printMessageDetails());
                        System.out.println("Total messages sent: " + msg.returnTotalMessages());
                    }
                    break;

                case "2":
                    
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    running = false;
                    System.out.println("Total messages sent: " + messagesSentCounter);
                    System.out.println("Quitting...");
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        } 
        input.close();
    }
}
        // TODO code application logic here

    

