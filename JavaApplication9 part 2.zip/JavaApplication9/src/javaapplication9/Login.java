/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication9;

/**
 *
 * @author Student
 */
public class Login {
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasCapital = false, hasNumber = false, hasSpecial = false;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) hasCapital = true;
            if (Character.isDigit(c)) hasNumber = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }
    public boolean checkCellPhoneNumber(String cellNumber) {
        if (cellNumber == null || cellNumber.length() > 13) return false;
        if (!cellNumber.startsWith("+")) return false;
        for (int i = 1; i < cellNumber.length(); i++) {
            if (!Character.isDigit(cellNumber.charAt(i))) return false;
        }
        return true;
    }
    public String registerUser(String username, String password, String cellNumber) {
        if (!checkUserName(username)) return "Username not correctly formatted";
        if (!checkPasswordComplexity(password)) return "Password not correctly formatted";
        if (!checkCellPhoneNumber(cellNumber)) return "Cell phone number incorrectly formatted";
        return "The two above conditions have been met, and the user has been registered successfully.";
    }
    public boolean loginUser(String loginUsername, String loginPassword, String registeredUsername, String registeredPassword) {
        return loginUsername.equals(registeredUsername) && loginPassword.equals(registeredPassword);
    }
    public String returnLoginStatus(boolean isLoggedIn, String firstName, String lastName) {
        if (isLoggedIn) return "Welcome " + firstName + " ," + lastName + " it is great to see you.";
        else return "Username or password incorrect, please try again.";
    }
}
    

